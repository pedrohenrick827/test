package lab05;

import java.util.Map;

public class Fornecedor {
	private String nome, email, telefone;
	private Map<IdProduto, Produto> produtos;
	
	public Fornecedor(String nome, String email, String telefone) {
		this.nome = nome; 
		this.email = email;
		this.telefone = telefone;
		
	}
	@Override
	public String toString() {
		return nome + " - " + email + " - " + telefone;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	public void adicionaProduto(String nome, String descricao, double preco) {
		IdProduto idProduto = new IdProduto(nome, descricao);
		if(produtos.containsKey(idProduto)) {
			throw new IllegalArgumentException("Erro no cadastro de produto: produto ja existe.");
		}else {
			Produto produto = new Produto(nome, descricao, preco);
			produtos.put(idProduto, produto);
		}
	}
	public void exibeProduto(String nomeProduto, String descricaoProduto) {
		IdProduto idProduto = new IdProduto(nomeProduto, descricaoProduto);
		if(produtos.containsKey(idProduto)) {
			produtos.get(idProduto).toString();
		}else {
			throw new IllegalArgumentException("Erro na exibicao de produto: produto nao existe.");
		}
	}
	
}
