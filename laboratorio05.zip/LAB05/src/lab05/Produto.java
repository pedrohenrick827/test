package lab05;

public class Produto {
	private String nome, descricao;
	private double preco;
	
	public Produto(String nome,String descricao,double preco) {
		this.nome = nome;
		this.descricao = descricao;
		this.preco = preco;
	}
	
	public String toString() {
		return nome + " - "  + descricao + " - R$" + preco; 
	}
}
