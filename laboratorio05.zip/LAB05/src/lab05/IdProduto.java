package lab05;

public class IdProduto {

	private String nome, descricao;
	
	public IdProduto(String nome, String descricao) {
		this.nome = nome;
		this.descricao = descricao;
	}
}
