package lab05;

public class Validacao {

	
	public void validaString(String string, String msg) {
		if(string == null) 
			throw new NullPointerException(msg);
		
		else if (string.trim().isEmpty()) 
			throw new IllegalArgumentException(msg);
		
		

	}
	
	public void validaCpf(String cpf, String msg) {
		if(cpf.length()!=11 || cpf.contains("^[a-Z]")) {
			throw new IllegalArgumentException(msg);
		}
	}
	public void validaPreco(double preco, String msg) {
		if(preco < 0) {
			throw new IllegalArgumentException(msg);
		}
	}
}
