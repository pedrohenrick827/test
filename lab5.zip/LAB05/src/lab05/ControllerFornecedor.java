package lab05;

import java.util.HashMap;
import java.util.Map;

public class ControllerFornecedor {
	private Map<String, Fornecedor> fornecedores;
	private Validacao valida;
	
	public ControllerFornecedor() {
		this.fornecedores = new HashMap<String, Fornecedor>();
		this.valida = new Validacao();
	}

	public void adicionaFornecedor(String nome, String email, String telefone) throws Exception {
		valida.validaString(nome, "Erro no cadastro do fornecedor: nome nao pode ser vazio ou nulo.");
		valida.validaString(email,"Erro no cadastro do fornecedor: email nao pode ser vazio ou nulo.");
		valida.validaString(telefone,  "Erro no cadastro do fornecedor: telefone nao pode ser vazio ou nulo.");
		if(this.fornecedores.containsKey(nome)) {
			throw new Exception("Erro no cadastro de fornecedor: fornecedor ja existe.");
		}else {
			Fornecedor novoFornecedor = new Fornecedor(nome, email, telefone);
			this.fornecedores.put(nome, novoFornecedor);
		}
		
	}

	public void exibeFornecedor(String nome) throws Exception {
		if(this.fornecedores.containsKey(nome)) {
			this.fornecedores.get(nome).toString();
		}else {
			throw new Exception("Erro na exibicao do fornecedor: fornecedor nao existe.");
		}
		
		
	}
	public void editaFornecedor(String nome, String atributo, String novoValor) throws Exception{
		valida.validaString(nome, "Erro na edicao do fornecedor: nome nao pode ser vazio ou nulo.");
		valida.validaString(atributo, "Erro na edicao do cliente: atributo nao pode ser vazio ou nulo.");
		valida.validaString(novoValor, "Erro na edicao do cliente: novo valor nao pode ser vazio ou nulo.");
		if(!this.fornecedores.containsKey(nome)) {
			throw new Exception("Erro na edicao do cliente: cliente nao existe.");
		}
		if(atributo.equals("nome")) {
			throw new Exception("Erro na edicao do fornecedor: nome nao pode ser editado.");
		}
		else if(atributo.equals("email")){
			this.fornecedores.get(nome).setEmail(novoValor);
		}else if(atributo.contentEquals("telefone")) {
			this.fornecedores.get(nome).setTelefone(novoValor);
		}else {
			throw new Exception("Erro na edicao do fornecedor: atributo nao existe.");
		}
	}
	public void removeFornecedor(String cpf) throws Exception {
		valida.validaString(cpf, "Erro na remocao do fornecedor: nome nao pode ser vazio ou nulo");
		if(this.fornecedores.containsKey(cpf)) {
			this.fornecedores.remove(cpf);
		}else {
			throw new Exception("Erro na remocao do fornecedor: fornecedor nao existe.");
		}
		
	}

}
