package lab05;

import easyaccept.EasyAccept;

public class SAGA {
	private ControllerCliente controllerCliente;
	private ControllerFornecedor controllerFornecedor;
	
	public static void main(String[] args) {
		args =  new String[] { "lab05.SAGA", "TesteAceitacao/use_case_1.txt"};
		EasyAccept.main(args);
	}
	
	public SAGA() {
		this.controllerCliente = new ControllerCliente();
		this.controllerFornecedor = new ControllerFornecedor();
	}
	
	public void adicionaCliente(String cpf, String nome, String email, String localizacao) {
		this.controllerCliente.adicionaCliente(cpf, nome, email, localizacao);
	}
	public void exibeCliente(String cpf) throws Exception {
		this.controllerCliente.exibeCliente(cpf);
	}
	public void editaCliente(String cpf, String atributo, String novoValor) throws Exception {
		this.controllerCliente.editaCliente(cpf,atributo,novoValor);
	}
	public void removeCliente(String cpf) throws Exception {
		this.controllerCliente.removeCliente(cpf);
	}
	public void adicionaFornecedor(String nome, String email, String telefone) throws Exception {
		this.controllerFornecedor.adicionaFornecedor(nome,email,telefone);
	}
	public void exibeFornecedor(String nome) throws Exception {
		this.controllerFornecedor.exibeFornecedor(nome);
	}
}
