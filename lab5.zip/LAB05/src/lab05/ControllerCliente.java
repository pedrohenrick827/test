package lab05;

import java.util.HashMap;
import java.util.Map;

public class ControllerCliente {
	private Map<String, Cliente> clientes;
	private Validacao valida;

	public ControllerCliente() {
		this.clientes = new HashMap<>();
		this.valida = new Validacao();
	}

	public String adicionaCliente(String cpf, String nome, String email, String localizacao) {
		valida.validaString(nome, "Erro no cadastro do cliente: nome nao pode ser vazio ou nulo.");
		valida.validaString(email, "Erro no cadastro do cliente: email nao pode ser vazio ou nulo.");
		valida.validaString(cpf, "Erro no cadastro do cliente: cpf nao pode ser vazio ou nulo.");
		valida.validaCpf(cpf, "Erro no cadastro do cliente: cpf invalido.");
		Cliente novoCliente = new Cliente(cpf, nome, email, localizacao);
		clientes.put(cpf, novoCliente);
		return cpf;
	}

	public void exibeCliente(String cpf) throws Exception {
		valida.validaString(cpf,"Erro na exibicao do cliente: cpf nao pode ser vazio ou nulo." );
		if(!clientes.containsKey(cpf)) {
			throw new Exception("Erro na exibicao do cliente: cliente nao existe.");
		}
		clientes.get(cpf).toString();
	}

	public void editaCliente(String cpf, String atributo, String novoValor) throws Exception {
		
		valida.validaString(cpf, "Erro na edicao do cliente: cpf nao pode ser vazio ou nulo.");
		valida.validaString(atributo, "Erro na edicao do cliente: atributo nao pode ser vazio ou nulo.");
		valida.validaString(novoValor, "Erro na edicao do cliente: novo valor nao pode ser vazio ou nulo.");
		if(!this.clientes.containsKey(cpf)) {
			throw new Exception("Erro na edicao do cliente: cliente nao existe.");
		}
		if(atributo.equals("cpf")) {
			throw new Exception("Erro na edicao do cliente: cpf nao pode ser editado.");
		}
		else if (atributo.equals("nome")) {
			this.clientes.get(cpf).setNome(novoValor);
		}else if(atributo.equals("email")){
			this.clientes.get(cpf).setEmail(novoValor);
		}else if(atributo.contentEquals("localizacao")) {
			this.clientes.get(cpf).setLocalizacao(novoValor);
		}else {
			throw new Exception("Erro na edicao do cliente: atributo nao existe.");
		}
		
		
	}

	public void removeCliente(String cpf) throws Exception {
		valida.validaString(cpf, "Erro na remocao do cliente: cpf nao pode ser vazio ou nulo");
		if(this.clientes.containsKey(cpf)) {
			this.clientes.remove(cpf);
		}else {
			throw new Exception("Erro na remocao do cliente: cliente nao existe.");
		}
		
	}
}
