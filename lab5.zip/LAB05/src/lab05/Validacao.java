package lab05;

public class Validacao {

	@SuppressWarnings("unused")
	public void validaString(String string, String msg) {
		if (string.trim().isEmpty() || string.equals(null))
			throw new IllegalArgumentException(msg);
		

	}
	@SuppressWarnings("unused")
	public void validaCpf(String cpf, String msg) {
		if(cpf.length()!=11 || cpf.contains("^[a-Z]")) {
			throw new IllegalArgumentException(msg);
		}
	}
}
