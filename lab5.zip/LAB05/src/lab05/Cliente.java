package lab05;

public class Cliente {
	private String cpf, nome, email, localizacao;

	
	public Cliente(String cpf, String nome, String email, String localizacao) {
		this.cpf = cpf;
		this.nome = nome;
		this.email = email;
		this.localizacao = localizacao;
	}
	@Override
	public String toString() {
		return nome + " - " + localizacao + " - " + email;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setLocalizacao(String localizacao) {
		this.localizacao = localizacao;
	}
}
